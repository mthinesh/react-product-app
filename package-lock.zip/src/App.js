import logo from './logo.svg';
import './App.css';
//import Products from './components/Products';
import { Route, Routes } from 'react-router-dom';
import Home from './components/Home';
import AllUsers from './components/AllUsers';
import Header from './components/Header';
//import EditUser from './components/EditUser';
import NotFound from './components/NotFound';
import React, { Suspense } from 'react';
import EditUser from './components/EditUser';
import AddUser from './components/AddUser';
import EditEmployee from './components/EditEmployee';
import AddEmployee from './components/AddEmployee';
import ViewProduct from './components/ViewProduct';
import Footer from './components/Footer';
const LazyAbout = React.lazy(()=> import('./components/About'))
const LazyEmployees = React.lazy(()=> import('./components/Employees'))
const LazyProducts = React.lazy(()=> import('./components/Product'))
const Lazyregistration = React.lazy(()=> import('./components/RegistrationForm'))

function App() {
  return (
      <>
      <Header/>
      <Routes>
        <Route path="/" element={<Home/>}/>
        <Route path="/all" element={<AllUsers/>} />
        <Route path="/edit/:id" element={<EditUser/>}/>
        <Route path="/add" element={<AddUser/>}/>
        <Route path="/addemployee" element={<AddEmployee/>}/>
        <Route path="about" element={<Suspense fallback={<div>Loading....</div>}> <LazyAbout/></Suspense>} />
        <Route path="registration" element={<Suspense fallback={<div>Loading....</div>}> <Lazyregistration/></Suspense>} />
        <Route path="employees" element={<Suspense fallback={<div>Loading....</div>}> <LazyEmployees/></Suspense>} ></Route>
        <Route path="/editemployee/:id" element={<EditEmployee/>}/>
        <Route path="/viewproduct/:id" element={<ViewProduct/>}/>
        <Route path="products" element={<Suspense fallback={<div class="text-center"> <div class="spinner-border" role="status"> <span class="sr-only">Loading...</span> </div> </div>}> <LazyProducts/></Suspense>} />
        <Route path="*" element={<NotFound/>}/>
        
      </Routes>
      <Footer/>
      </>
      
  );
}

export default App;
