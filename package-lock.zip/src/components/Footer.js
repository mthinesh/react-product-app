import React from 'react'

export default function Footer() {
  return (
    <div class="d-flex justify-content-between py-1 my-1 border-top">
      <p>&copy; 2023 PMT Textile, Pvt. All rights reserved.</p>
    
    </div>
  )
}
