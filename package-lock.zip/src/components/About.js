import React from 'react'

export default function About() {
  return (
    <h4>About Us</h4>
  )
}
